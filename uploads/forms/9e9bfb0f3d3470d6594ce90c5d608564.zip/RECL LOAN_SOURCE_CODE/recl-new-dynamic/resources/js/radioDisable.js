$(document).ready(function(){
	$('input[type="radio"]').attr('disabled','disabled');
});