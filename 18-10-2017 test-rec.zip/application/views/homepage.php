<?php $this->load->view('includes/header'); ?>

<?php $this->load->view('includes/form-navigation'); ?>

  <section class="loginform">

    <div class="container">
<style>
body{background-image: url(http://www.recindia.nic.in/images/languagePageBg.jpg);
        background-size: cover;
    background-position: center center;
    background-repeat: no-repeat;}
</style>
      <div class="row">

        <div class="col-md-6 col-md-offset-3">

         <div class="form">

          <form class="" action="<?php echo $action;?>" method="<?php echo $action_method;?>">

          <div class="loginheading">

          <h3>LOG IN</h3>

          </div>

          <?php echo $this->session->flashdata('success');?>

            <div class="form-group col-md-12">

              <input name="email" type="text" class="form-control" placeholder="EMAIL ID" value="<?php echo set_value('email')?>">

              <?php echo form_error('email');?>

            </div>

            <div class="form-group col-md-12">

              <input name="password" type="password" class="form-control" placeholder="PASSWORD" value="<?php echo set_value('password')?>">

              <?php echo form_error('password');?>

            </div>

            <div class="col-md-12">

              <button type="submit" class="btn btnwide btn-warning">LOGIN</button>

            </div>

            <div class="col-md-6 col-sm-6 text-left forgotlink">

            <a href="<?php echo base_url();?>signup">Create New Account</a>

            </div>

            <div class="col-md-6 col-sm-6 text-right forgotlink">

            <a href="<?php echo base_url();?>forgot-password">Forgot Password?</a>

            </div>

          </form>
          
          </div>

        </div>

      </div>

    </div>

  </section>

<?php $this->load->view('includes/footer'); ?>